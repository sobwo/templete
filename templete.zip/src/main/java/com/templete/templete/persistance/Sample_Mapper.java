package com.templete.templete.persistance;

public interface Sample_Mapper {

}
