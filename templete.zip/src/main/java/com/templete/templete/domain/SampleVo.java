package com.templete.templete.domain;

import lombok.Getter;
import lombok.Setter;

@Getter 
@Setter
public class SampleVo {
	String sample;
}
