package com.templete.templete.service;

public interface SampleService {

}
